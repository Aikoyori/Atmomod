package com.atmosphex.atmomod.items;
import com.atmosphex.atmomod.Reference;
import net.minecraft.item.Item;

public class ItemAquar extends Item {
	public ItemAquar()
	{
		setUnlocalizedName(Reference.AtmosphexItems.AQUAR.getUnlocalizedName());
		setRegistryName(Reference.AtmosphexItems.AQUAR.getRegistryName());
	}
}
