package com.atmosphex.atmomod.proxy;

public class ServerProxy implements CommonProxy	 {

	@Override
	public void init() {
		// TODO Auto-generated method stub
		
	}

}
