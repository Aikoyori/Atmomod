
package com.atmosphex.atmomod.proxy;

public interface CommonProxy{
	public void init();
}
